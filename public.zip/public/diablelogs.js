window.console.log = function() {};
window.console.warn = function() {};
window.console.error = function() {};
